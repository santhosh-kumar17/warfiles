boxfuse-sample-java-war-hello
=============================

Boxfuse Sample Hello World Java application packaged as a war file

## Prerequisites

- Git
- Java
- Maven
- VirtualBox
- Boxfuse

## Running

1. git clone https://github.com/boxfuse/boxfuse-sample-java-war-hello
2. cd boxfuse-sample-java-war-hello
3. mvn package
4. boxfuse run target/hello-1.0.war

Done!

Open your browser at http://localhost:8888 or simple type ```boxfuse open hello:1.0``` to see your brand new instance in action!
